<?php

namespace Database\Seeders;

use App\Models\Course;
use App\Models\Material;
use App\Models\User;
use Illuminate\Database\Seeder;

class MaterialSeeder extends Seeder
{
    public function run(): void
    {
        // Materiales por especialidad — se aplican a TODOS los cursos con ese nombre
        // Cada especialidad tiene 3 materiales: link, document, link
        $materialsBySubject = [
            'Matemática' => [
                ['title' => 'Guía de Álgebra y Funciones',           'type' => 'document', 'url' => 'https://recursos.perueduca.pe/matematica-algebra.pdf',         'description' => 'Material de estudio sobre álgebra básica y funciones matemáticas.'],
                ['title' => 'Khan Academy — Matemáticas',            'type' => 'link',     'url' => 'https://es.khanacademy.org/math',                               'description' => 'Plataforma interactiva con ejercicios y videos de matemáticas.'],
                ['title' => 'Problemas de razonamiento matemático',  'type' => 'document', 'url' => 'https://recursos.perueduca.pe/razonamiento-mat.pdf',             'description' => 'Colección de problemas para reforzar el razonamiento lógico.'],
            ],
            'Comunicación' => [
                ['title' => 'Guía de Comprensión Lectora',           'type' => 'link',     'url' => 'https://www.lecturayvida.fahce.unlp.edu.ar/',                   'description' => 'Recursos para mejorar la comprensión de textos literarios y expositivos.'],
                ['title' => 'Ortografía y Redacción — Cuadernillo',  'type' => 'document', 'url' => 'https://recursos.perueduca.pe/ortografia-redaccion.pdf',         'description' => 'Ejercicios prácticos de ortografía y redacción de textos.'],
                ['title' => 'Técnicas de expresión oral',            'type' => 'link',     'url' => 'https://www.eduteka.icesi.edu.co/articulos/ExprOralestrategias', 'description' => 'Estrategias para mejorar la expresión oral en el aula.'],
            ],
            'Inglés' => [
                ['title' => 'Duolingo — Práctica de Inglés',         'type' => 'link',     'url' => 'https://www.duolingo.com/course/en/es',                         'description' => 'Aplicación gamificada para aprender inglés de forma diaria.'],
                ['title' => 'Grammar in Use — Basic',                'type' => 'document', 'url' => 'https://recursos.perueduca.pe/grammar-basic.pdf',               'description' => 'Fundamentos de gramática inglesa con ejercicios.'],
                ['title' => 'BBC Learning English',                  'type' => 'link',     'url' => 'https://www.bbc.co.uk/learningenglish',                         'description' => 'Recursos de la BBC para aprender inglés con audio y video.'],
            ],
            'Ciencia y Tecnología' => [
                ['title' => 'Experimentos caseros de Física',        'type' => 'link',     'url' => 'https://www.cienciasfera.com/experimentos',                     'description' => 'Guía de experimentos sencillos para aprender ciencias.'],
                ['title' => 'Cuaderno de Ciencias — Bimestre I',    'type' => 'document', 'url' => 'https://recursos.perueduca.pe/ciencias-bim1.pdf',               'description' => 'Material oficial del MINEDU para Ciencia y Tecnología.'],
                ['title' => 'NASA Kids Club',                        'type' => 'link',     'url' => 'https://www.nasa.gov/kidsclub',                                 'description' => 'Recursos interactivos sobre ciencia y tecnología espacial.'],
            ],
            'Ciencias Sociales' => [
                ['title' => 'Historia del Perú — Resumen visual',   'type' => 'document', 'url' => 'https://recursos.perueduca.pe/historia-peru.pdf',               'description' => 'Línea de tiempo y resumen de la historia del Perú.'],
                ['title' => 'Geografía del Perú — Mapas',           'type' => 'link',     'url' => 'https://www.inei.gob.pe/mapas',                                 'description' => 'Atlas digital del Perú con información geográfica actualizada.'],
                ['title' => 'Economía básica para escolares',       'type' => 'document', 'url' => 'https://recursos.perueduca.pe/economia-escolar.pdf',             'description' => 'Conceptos básicos de economía aplicados al contexto peruano.'],
            ],
            'Desarrollo Personal, Ciudadanía y Cívica' => [
                ['title' => 'Constitución Política del Perú',        'type' => 'link',     'url' => 'https://www.tc.gob.pe/tc/private/adjuntos/institucional/constitucion.pdf', 'description' => 'Texto completo de la Constitución Política del Perú de 1993.'],
                ['title' => 'Derechos y deberes del ciudadano',      'type' => 'document', 'url' => 'https://recursos.perueduca.pe/ciudadania-derechos.pdf',          'description' => 'Guía sobre los derechos fundamentales y deberes ciudadanos.'],
                ['title' => 'Proyecto de vida — Taller',            'type' => 'document', 'url' => 'https://recursos.perueduca.pe/proyecto-vida.pdf',               'description' => 'Talleres para la construcción del proyecto de vida personal.'],
            ],
            'Arte y Cultura' => [
                ['title' => 'Técnicas de dibujo y pintura',         'type' => 'link',     'url' => 'https://www.arteperuano.com/tecnicas',                          'description' => 'Video tutoriales de técnicas artísticas básicas.'],
                ['title' => 'Historia del arte peruano',            'type' => 'document', 'url' => 'https://recursos.perueduca.pe/arte-peruano.pdf',                'description' => 'Recorrido por las principales expresiones artísticas del Perú.'],
                ['title' => 'Músicas del mundo — Spotify',         'type' => 'link',     'url' => 'https://open.spotify.com/playlist/37i9dQZF1DXbsGtMiOECbN',      'description' => 'Playlist de músicas del mundo para educación musical.'],
            ],
            'Educación para el Trabajo' => [
                ['title' => 'Manualidades y diseño básico',         'type' => 'link',     'url' => 'https://www.manualidades.com',                                  'description' => 'Recursos prácticos de manualidades y diseño artesanal.'],
                ['title' => 'Emprendimiento juvenil — Guía',        'type' => 'document', 'url' => 'https://recursos.perueduca.pe/emprendimiento-juvenil.pdf',       'description' => 'Guía del MINEDU para el desarrollo de competencias laborales.'],
                ['title' => 'Canva para escolares',                 'type' => 'link',     'url' => 'https://www.canva.com/education',                               'description' => 'Herramienta gratuita de diseño gráfico para estudiantes.'],
            ],
            'Educación Física' => [
                ['title' => 'Plan de acondicionamiento físico',     'type' => 'document', 'url' => 'https://recursos.perueduca.pe/acondicionamiento-fisico.pdf',     'description' => 'Rutinas de calentamiento y ejercicios para el desarrollo físico.'],
                ['title' => 'Reglamento de fútbol y vóley',        'type' => 'link',     'url' => 'https://www.ipd.gob.pe/reglamentos',                            'description' => 'Reglamentos oficiales de deportes más practicados en el Perú.'],
                ['title' => 'Nutrición y deporte escolar',         'type' => 'document', 'url' => 'https://recursos.perueduca.pe/nutricion-deporte.pdf',            'description' => 'Guía de alimentación saludable para deportistas escolares.'],
            ],
            'Educación Religiosa' => [
                ['title' => 'Valores y ética cristiana',           'type' => 'document', 'url' => 'https://recursos.perueduca.pe/etica-cristiana.pdf',             'description' => 'Material de reflexión sobre valores humanos y cristianos.'],
                ['title' => 'Proyecto Solidario Escolar',          'type' => 'link',     'url' => 'https://www.caritas.org.pe/educacion',                          'description' => 'Propuestas de proyectos solidarios para la comunidad escolar.'],
            ],
            'Lengua Originaria' => [
                ['title' => 'Diccionario Quechua — Español',       'type' => 'link',     'url' => 'https://qichwasimipi.amethi.net/',                              'description' => 'Diccionario en línea Quechua-Español con pronunciación.'],
                ['title' => 'Canciones y cuentos en Quechua',      'type' => 'document', 'url' => 'https://recursos.perueduca.pe/quechua-cuentos.pdf',             'description' => 'Material cultural con canciones y cuentos tradicionales en Quechua.'],
                ['title' => 'Runasimi — Aprende Quechua',          'type' => 'link',     'url' => 'https://runasimi.de',                                           'description' => 'Portal de aprendizaje de la lengua Quechua en línea.'],
            ],
        ];

        // Para cada sección obtenemos sus cursos y asignamos materiales
        // Solo lo hacemos por las primeras 2 secciones para no duplicar miles de materiales
        // (en la vida real, cada docente sube sus propios materiales por sección)
        // Aquí sembramos materiales globales por nombre de curso (usando la sección 1 y 2)
        $processedNames = [];

        $courses = Course::with('teacher')->get();

        foreach ($courses as $course) {
            $name = $course->name;
            // Solo un set de materiales por nombre de curso (no duplicar por sección)
            if (isset($processedNames[$name])) continue;
            $processedNames[$name] = true;

            $mats = $materialsBySubject[$name] ?? [];
            foreach ($mats as $mat) {
                Material::create([
                    'title'       => $mat['title'],
                    'type'        => $mat['type'],
                    'url'         => $mat['url'],
                    'description' => $mat['description'],
                    'course_id'   => $course->id,
                    'teacher_id'  => $course->teacher_id,
                ]);
            }
        }
    }
}
