<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            AcademicYearSeeder::class,   // 2025 (finished) + 2026 (enrollment_open)
            UserSeeder::class,            // admin + 11 docentes + 1500 alumnos + 750 padres
            SectionSeeder::class,         // 50 secciones 2026 (A-J × 5 grados) + 10 históricas 4° 2025
            CourseSeeder::class,          // 11 cursos × 60 secciones = 660 cursos
            EnrollmentSeeder::class,      // 1500 matrículas 2026 + 300 históricas 2025 (5° → 4°)
            GradeSeeder::class,           // notas 2026 y 2025, distribución real por materia
            AttendanceSeeder::class,      // asistencia últimas 4 semanas (2026 solamente)
            AnnouncementSeeder::class,    // comunicados institucionales 2026
            ScheduleSeeder::class,        // horarios secciones 2026 (35 slots × 50 secciones)
            MaterialSeeder::class,        // materiales por especialidad
            AcademicEventSeeder::class,   // eventos del calendario 2026
            ParentStudentSeeder::class,   // 750 vínculos padre-hijo (2 hijos por padre) + apoderado
        ]);
    }
}
