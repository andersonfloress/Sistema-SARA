<?php

namespace Database\Seeders;

use App\Models\Enrollment;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class GradeSeeder extends Seeder
{
    public function run(): void
    {
        $admin   = User::where('role', 'admin')->first();
        $periods = ['I', 'II', 'III'];
        $now     = now();

        // Distribución de notas por materia (acumulativo %)
        // Umbrales: [%graveFail(<11), %totalFail, %regular(13-15), %bueno(16-17)]
        // Lo que supere el 4to umbral → excelente (18-20)
        $scoreConfig = [
            'Matemática'                               => [8,  20, 55, 80],
            'Comunicación'                             => [5,  15, 50, 78],
            'Inglés'                                   => [6,  17, 52, 79],
            'Ciencia y Tecnología'                     => [7,  18, 53, 79],
            'Ciencias Sociales'                        => [4,  11, 46, 77],
            'Desarrollo Personal, Ciudadanía y Cívica' => [2,   6, 31, 70],
            'Arte y Cultura'                           => [1,   3, 23, 65],
            'Educación para el Trabajo'                => [1,   3, 23, 65],
            'Educación Física'                         => [1,   3, 18, 58],
            'Educación Religiosa'                      => [1,   3, 21, 63],
            'Lengua Originaria'                        => [3,   8, 33, 68],
        ];
        $defaultCfg = [5, 15, 50, 78];

        // Cargar todas las matrículas con cursos de su sección
        $enrollments = Enrollment::with('section.courses')->get();

        $rows = [];

        foreach ($enrollments as $enrollment) {
            foreach ($enrollment->section->courses as $course) {
                $cfg = $scoreConfig[$course->name] ?? $defaultCfg;

                foreach ($periods as $period) {
                    $r     = rand(1, 100);
                    $score = match (true) {
                        $r <= $cfg[0] => rand(5, 10),   // reprueba grave
                        $r <= $cfg[1] => rand(11, 12),  // en riesgo
                        $r <= $cfg[2] => rand(13, 15),  // regular
                        $r <= $cfg[3] => rand(16, 17),  // bueno
                        default       => rand(18, 20),  // excelente
                    };

                    // Ligera mejora en períodos posteriores (alumnos progresan)
                    if ($period === 'III') {
                        $score = min(20, $score + rand(0, 1));
                    } elseif ($period === 'II') {
                        if (rand(1, 3) === 1) $score = min(20, $score + 1);
                    }

                    // Observación automática según nivel de logro
                    $observation = null;
                    if ($score < 11) {
                        $obs = [
                            'Estudiante requiere recuperación académica. Se recomienda reforzamiento y seguimiento con el padre de familia.',
                            'Rendimiento por debajo del nivel esperado. Necesita apoyo adicional y mayor participación en clase.',
                            'Estudiante no alcanza los logros del período. Se cita al apoderado para establecer compromisos de mejora.',
                            'Se evidencian dificultades en el aprendizaje del área. Requiere tutoría y acompañamiento permanente.',
                            'Bajo nivel de logro. Se recomienda asistir a las jornadas de recuperación programadas por la institución.',
                        ];
                        $observation = $obs[($enrollment->student_id + $course->id) % 5];
                    } elseif ($score <= 12) {
                        $obs = [
                            'Estudiante en proceso. Se sugiere mayor dedicación y participación en clases.',
                            'Logro en inicio. Necesita reforzar los temas trabajados y completar las tareas asignadas.',
                            'Rendimiento regular. Se recomienda repasar los contenidos del período y consultar al docente.',
                            'En proceso de desarrollo de competencias. Requiere mayor esfuerzo y constancia en el estudio.',
                            'Nivel básico alcanzado. Se sugiere participar activamente en las actividades de aula.',
                        ];
                        $observation = $obs[($enrollment->student_id + $course->id) % 5];
                    }

                    $rows[] = [
                        'student_id'  => $enrollment->student_id,
                        'course_id'   => $course->id,
                        'period'      => $period,
                        'score'       => $score,
                        'observation' => $observation,
                        'created_by'  => $admin->id,
                        'created_at'  => $now,
                        'updated_at'  => $now,
                    ];

                    if (count($rows) >= 1000) {
                        DB::table('grades')->insertOrIgnore($rows);
                        $rows = [];
                    }
                }
            }
        }

        if (!empty($rows)) {
            DB::table('grades')->insertOrIgnore($rows);
        }
        // 2026: 1500 × 11 × 3 = 49 500 notas
        // 2025: 300  × 11 × 3 =  9 900 notas históricas
        // Total: ~59 400 notas
    }
}
