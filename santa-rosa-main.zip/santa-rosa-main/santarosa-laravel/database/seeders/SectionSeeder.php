<?php

namespace Database\Seeders;

use App\Models\Section;
use Illuminate\Database\Seeder;

class SectionSeeder extends Seeder
{
    public function run(): void
    {
        // ── Secciones activas 2026 — 10 por grado (A-J), 5 grados ──────────
        // A-E turno mañana | F-J turno tarde
        $letters = ['A','B','C','D','E','F','G','H','I','J'];

        foreach (range(1, 5) as $grade) {
            foreach ($letters as $i => $letter) {
                $turno = $i < 5 ? 'mañana' : 'tarde';
                Section::create([
                    'name'         => "{$grade}° {$letter}",
                    'grade'        => $grade,
                    'year'         => 2026,
                    'turno'        => $turno,
                    'cupo_maximo'  => 30,
                ]);
            }
        }
        // Resultado: 50 secciones 2026 (IDs 1-50)

        // ── Secciones históricas 2025 — solo 4° grado (para historial de 5°) ─
        foreach ($letters as $i => $letter) {
            $turno = $i < 5 ? 'mañana' : 'tarde';
            Section::create([
                'name'         => "4° {$letter}",
                'grade'        => 4,
                'year'         => 2025,
                'turno'        => $turno,
                'cupo_maximo'  => 30,
            ]);
        }
        // Resultado: 10 secciones históricas 2025 (IDs 51-60)
        // Total: 60 secciones
    }
}
