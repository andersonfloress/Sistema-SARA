<?php

namespace Database\Seeders;

use App\Models\ParentProfile;
use App\Models\StudentProfile;
use App\Models\TeacherProfile;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();

        // ── ADMIN ──────────────────────────────────────────────────────────
        User::create([
            'name'     => 'Dirección IE Santa Rosa',
            'email'    => 'admin@santarosa.edu.pe',
            'password' => Hash::make('admin123'),
            'role'     => 'admin',
        ]);

        // ── DOCENTES — 63 en total, distribuidos por especialidad ─────────
        // Distribución: Matemática(9), Comunicación(9), Inglés(5),
        // Ciencia y Tecnología(7), Ciencias Sociales(7), DPCC(4),
        // Arte y Cultura(4), Ed. Trabajo(4), Ed. Física(5), Ed. Religiosa(4), Lengua Originaria(5)
        // Cada docente cubre ~5-10 secciones según horas/semana de su materia.

        $specialtyConfig = [
            ['Matemática',                               5, 9 ],
            ['Comunicación',                             5, 9 ],
            ['Inglés',                                   3, 5 ],
            ['Ciencia y Tecnología',                     4, 7 ],
            ['Ciencias Sociales',                        4, 7 ],
            ['Desarrollo Personal, Ciudadanía y Cívica', 2, 4 ],
            ['Arte y Cultura',                           2, 4 ],
            ['Educación para el Trabajo',                2, 4 ],
            ['Educación Física',                         3, 5 ],
            ['Educación Religiosa',                      2, 4 ],
            ['Lengua Originaria',                        3, 5 ],
        ];
        // Total: 9+9+5+7+7+4+4+4+5+4+5 = 63 docentes

        // Nombres masculinos de docentes — adultos peruanos 30-55 años
        $nombresDocM = [
            'Abelardo','Alberto','Aurelio','Bernabé','César','Dante','Edilberto','Florencio',
            'Gilberto','Heriberto','Isidoro','Javier','Leonidas','Miguel','Narciso','Osmán',
            'Pablo','Renato','Santiago','Ulises','Valentín','Walter','Amador','Benito',
            'Cornelio','Dionisio','Eugenio','Fabio','Gerardo','Hugo',
            'Iván','Jorge','Kléver',
        ];
        // Nombres femeninos de docentes
        $nombresDocF = [
            'Aída','Beatriz','Carla','Débora','Elena','Fanny','Gloria','Hilda',
            'Irene','Juana','Karina','Lourdes','Mirtha','Nelly','Ofelia','Pilar',
            'Rosario','Silvana','Teresa','Verónica','Ximena','Zoila','Adela','Blanca',
            'Carmen','Dora','Eva','Faviola','Graciela','Haydée',
            'Ingrid','Jimena','Ketty',
        ];
        $apellidos = [
            'Mamani','Quispe','Condori','Apaza','Huanca','Ccama','Larico','Lupaca',
            'Callo','Coaquira','Turpo','Calisaya','Ticona','Puma','Chura','Copa',
            'Limachi','Vilca','Coila','Cutipa','Huanacuni','Soncco','Pacori','Tacca',
            'Pilco','Ayca','Hancco','Zela','Cari','Llanque',
            'Flores','Ramos','Cruz','Vargas','Torres','García','López','Medina',
            'Rojas','Castro',
        ];
        $distritos = ['Puno','Puno','Puno','Juliaca','Juliaca','Ilave','Azángaro','Yunguyo','Lampa','Puno'];
        $calles    = [
            'Jr. Deustua','Jr. Lima','Av. El Sol','Jr. Moquegua','Jr. Arequipa',
            'Calle Libertad','Av. Costanera','Jr. Tacna','Av. Simón Bolívar','Jr. Puno',
        ];
        $nivelesAcad   = ['bachiller','licenciado','licenciado','licenciado','magister','magister','licenciado'];
        $condiciones   = ['nombrado','nombrado','nombrado','contratado','nombrado','nombrado','contratado'];
        $emergNames    = [
            'Rosa','Carmen','María','Ana','Lucía','Sofía','Elena','Claudia','Patricia','Norma',
            'Jorge','Pedro','Luis','Carlos','Manuel','José','Antonio','Roberto','Julio','Víctor',
        ];

        $teacherIdx = 0;

        foreach ($specialtyConfig as [$specialty, $horasSemana, $count]) {
            for ($t = 0; $t < $count; $t++) {
                $isMale    = ($teacherIdx % 2 === 0);
                $firstName = $isMale
                    ? $nombresDocM[$teacherIdx % count($nombresDocM)]
                    : $nombresDocF[$teacherIdx % count($nombresDocF)];
                $ap1 = $apellidos[($teacherIdx * 3 + 5) % 40];
                $ap2 = $apellidos[($teacherIdx * 7 + 13) % 40];
                if ($ap1 === $ap2) $ap2 = $apellidos[($teacherIdx * 7 + 14) % 40];

                $num   = str_pad($teacherIdx + 1, 2, '0', STR_PAD_LEFT);
                $email = "profe{$num}@santarosa.edu.pe";
                $name  = "{$firstName} {$ap1} {$ap2}";

                $user = User::create([
                    'name'     => $name,
                    'email'    => $email,
                    'password' => Hash::make('profe123'),
                    'role'     => 'teacher',
                ]);

                // Fecha de nacimiento: 35-55 años (nacidos 1970-1990)
                $birthYear  = 1970 + ($teacherIdx % 21);
                $birthMonth = str_pad(($teacherIdx % 12) + 1, 2, '0', STR_PAD_LEFT);
                $birthDay   = str_pad(($teacherIdx % 28) + 1, 2, '0', STR_PAD_LEFT);

                // Año de ingreso según condición laboral
                $condicion   = $condiciones[$teacherIdx % 7];
                $nivel       = $nivelesAcad[$teacherIdx % 7];
                $ingresoYear = $condicion === 'nombrado'
                    ? 2004 + ($teacherIdx % 12)  // 2004-2015
                    : 2016 + ($teacherIdx % 8);  // 2016-2023

                $telefono   = '951' . str_pad(100000 + $teacherIdx * 137, 6, '0', STR_PAD_LEFT);
                $telAlt     = '952' . str_pad(100000 + $teacherIdx * 97,  6, '0', STR_PAD_LEFT);
                $distrito   = $distritos[$teacherIdx % 10];
                $calle      = $calles[$teacherIdx % 10];
                $numero     = 100 + ($teacherIdx * 11 % 900);
                $dni        = '4' . str_pad(2000000 + $teacherIdx * 173, 7, '0', STR_PAD_LEFT);

                $emergFirstName = $emergNames[$teacherIdx % 20];
                $emergAp        = $apellidos[($teacherIdx * 5 + 3) % 40];
                $emergTel       = '950' . str_pad(200000 + $teacherIdx * 83, 6, '0', STR_PAD_LEFT);

                // Nombre de usuario para correo alternativo
                $emailUser = strtolower(
                    iconv('UTF-8', 'ASCII//TRANSLIT',
                        substr($firstName, 0, 1) . $ap1
                    )
                );

                TeacherProfile::create([
                    'teacher_id'                   => $user->id,
                    'dni'                          => $dni,
                    'codigo_docente'               => 'DOC-' . str_pad($teacherIdx + 1, 3, '0', STR_PAD_LEFT),
                    'especialidad'                 => $specialty,
                    'telefono'                     => $telefono,
                    'direccion'                    => "{$calle} {$numero}, {$distrito}",
                    'fecha_nacimiento'             => "{$birthYear}-{$birthMonth}-{$birthDay}",
                    'sexo'                         => $isMale ? 'M' : 'F',
                    'foto_perfil'                  => null,
                    'correo_alternativo'           => "{$emailUser}.docente@gmail.com",
                    'contacto_emergencia_nombre'   => "{$emergFirstName} {$emergAp}",
                    'contacto_emergencia_telefono' => $emergTel,
                    'fecha_ingreso'                => "{$ingresoYear}-03-01",
                    'condicion_laboral'            => $condicion,
                    'nivel_academico'              => $nivel,
                    'numero_colegiatura'           => 'CPPe-' . str_pad(30000 + $teacherIdx * 1117 % 70000, 6, '0', STR_PAD_LEFT),
                    'turno'                        => 'ambos',
                    'cv_path'                      => null,
                    'max_horas_semanales'          => 30,
                ]);

                $teacherIdx++;
            }
        }

        // ── ALUMNOS — 1 500 (10 secciones × 5 grados × 30 alumnos) ────────
        $nombresAlumnoM = [
            'Jhonatan','Brayan','Erick','Yonatan','Cristian','Anderson','Kevin','Diego',
            'Luis','Carlos','Rodrigo','Aldair','Fabricio','Ángel','Junior','Antony',
            'Josué','Samuel','David','Alexis','Percy','Frank','Víctor','Edgardo',
            'Nelson','Paul','Walter','Iván','Henry','Omar',
            'César','Wilmer','Raúl','Abel','Noe','Jerson','Elmer','Javier','Marco','Ronaldo',
        ];
        $nombresAlumnaF = [
            'Milagros','Fiorella','Fátima','Xiomara','Yessenia','Zaira','Lucero','Marisol',
            'Yaneth','Yomira','Deysi','Anahi','Sheyla','Pamela','Liz','Karina',
            'Noemi','Rocío','Sandra','Estefany','Nadia','Cinthia','Yeni','Flor',
            'Rosa','Karen','Wendy','Evelyn','Bertha','Gladys',
            'Elsa','Ruth','Haydee','Sonia','Carmen','Patricia','Nilda','Silvia','Norma','Olga',
        ];
        $tiposSangre = ['O+','O+','O+','O+','O+','O+','A+','A+','A+','A+','B+','B+','AB+','O-','A-'];

        // Pre-computar hash (velocidad con 1500 usuarios)
        $hashAlumno = Hash::make('alumno123');

        $studentUserRows = [];
        $studentProfRows = [];
        $studentIdx      = 0;

        for ($grade = 1; $grade <= 5; $grade++) {
            $anioIngreso   = 2026 - $grade + 1;
            $birthYearBase = 2026 - $grade - 12; // grado1→2013, grado5→2009

            for ($sec = 0; $sec < 10; $sec++) {
                $turno = $sec < 5 ? 'mañana' : 'tarde';

                for ($n = 0; $n < 30; $n++) {
                    $isMale  = ($studentIdx % 2 === 0);
                    $nIdx    = $studentIdx % 40;
                    $ap1Idx  = ($studentIdx * 3 + $grade) % 40;
                    $ap2Idx  = ($studentIdx * 7 + $sec + 11) % 40;
                    if ($ap1Idx === $ap2Idx) $ap2Idx = ($ap2Idx + 1) % 40;

                    $nombre   = $isMale ? $nombresAlumnoM[$nIdx] : $nombresAlumnaF[$nIdx];
                    $ap1      = $apellidos[$ap1Idx];
                    $ap2      = $apellidos[$ap2Idx];
                    $num      = str_pad($studentIdx + 1, 4, '0', STR_PAD_LEFT);

                    $studentUserRows[] = [
                        'name'       => "{$nombre} {$ap1} {$ap2}",
                        'email'      => "alumno{$num}@santarosa.edu.pe",
                        'password'   => $hashAlumno,
                        'role'       => 'student',
                        'created_at' => $now,
                        'updated_at' => $now,
                    ];

                    $birthYear  = $birthYearBase + ($studentIdx % 2);
                    $birthMonth = str_pad(($studentIdx % 12) + 1, 2, '0', STR_PAD_LEFT);
                    $birthDay   = str_pad(($n % 28) + 1, 2, '0', STR_PAD_LEFT);
                    $telefono   = '9' . str_pad(51000000 + $studentIdx * 3, 8, '0', STR_PAD_LEFT);
                    $distrito   = $distritos[$studentIdx % 10];
                    $calle      = $calles[$studentIdx % 10];
                    $numero     = 100 + ($studentIdx % 900);

                    $studentProfRows[] = [
                        'student_id'         => 0, // se reemplaza abajo
                        'codigo_estudiante'  => 'EST-' . $num,
                        'dni'                => '7' . str_pad(1000000 + $studentIdx, 7, '0', STR_PAD_LEFT),
                        'fecha_nacimiento'   => "{$birthYear}-{$birthMonth}-{$birthDay}",
                        'sexo'               => $isMale ? 'M' : 'F',
                        'grado'              => $grade,
                        'turno'              => $turno,
                        'direccion'          => "{$calle} {$numero}, {$distrito}",
                        'telefono'           => $telefono,
                        'nacionalidad'       => 'Peruana',
                        'tipo_sangre'        => $tiposSangre[$studentIdx % 15],
                        'foto_perfil'        => null,
                        'anio_ingreso'       => $anioIngreso,
                        'nombre_apoderado'   => null,
                        'dni_apoderado'      => null,
                        'telefono_emergencia'=> null,
                        'condicion_especial' => null,
                        'created_at'         => $now,
                        'updated_at'         => $now,
                    ];

                    $studentIdx++;
                }
            }
        }

        foreach (array_chunk($studentUserRows, 200) as $chunk) {
            DB::table('users')->insert($chunk);
        }
        $studentIds = User::where('role', 'student')->orderBy('id')->pluck('id')->toArray();
        foreach ($studentProfRows as $i => &$row) {
            $row['student_id'] = $studentIds[$i];
        }
        unset($row);
        foreach (array_chunk($studentProfRows, 200) as $chunk) {
            DB::table('student_profiles')->insert($chunk);
        }

        // ── PADRES — 750, 2 hijos cada uno ───────────────────────────────
        $nombresPM = [
            'Gregorio','Fortunato','Dionisio','Félix','Juan','Pedro','Manuel','Eugenio',
            'Victoriano','Marcelino','Isidro','Celestino','Eusebio','Cirilo','Florentino',
            'Anastasio','Nicanor','Timoteo','Arcadio','Pascual','Andrés','Basilio',
            'Desiderio','Edilberto','Filomeno','Godofredo','Herminio','Ildefonso','Justo','Laureano',
        ];
        $nombresPF = [
            'Filomena','Dionisia','Celestina','Eusebia','Isidora','Florinda','Marcelina',
            'Anastasia','Nicasia','Timotea','Arcadia','Pascuala','Gregoria','Fortunata',
            'Victoriana','Bernardina','Catalina','Dominga','Epifania','Faustina',
            'Gavina','Hilaria','Juana','Lucinda','Macedonia','Natividad','Obdulia','Perpetua','Quintina','Rufina',
        ];
        $ocupaciones = [
            'Agricultor/a','Comerciante','Docente','Obrero/a','Técnico/a en salud',
            'Taxista','Artesano/a','Ama de casa','Enfermero/a','Policía',
        ];

        $hashPadre   = Hash::make('padre123');
        $parentRows  = [];
        $pProfRows   = [];

        for ($p = 0; $p < 750; $p++) {
            $isMale = ($p % 2 === 0);
            $fIdx   = $p % 30;
            $ap1Idx = ($p * 5 + 3) % 40;
            $ap2Idx = ($p * 11 + 7) % 40;
            if ($ap1Idx === $ap2Idx) $ap2Idx = ($ap2Idx + 2) % 40;

            $nombre = $isMale ? $nombresPM[$fIdx] : $nombresPF[$fIdx];
            $ap1    = $apellidos[$ap1Idx];
            $ap2    = $apellidos[$ap2Idx];
            $num    = str_pad($p + 1, 3, '0', STR_PAD_LEFT);

            $parentRows[] = [
                'name'       => "{$nombre} {$ap1} {$ap2}",
                'email'      => "padre{$num}@santarosa.edu.pe",
                'password'   => $hashPadre,
                'role'       => 'parent',
                'created_at' => $now,
                'updated_at' => $now,
            ];

            $bYear  = 1968 + ($p % 21);
            $bMonth = str_pad(($p % 12) + 1, 2, '0', STR_PAD_LEFT);
            $bDay   = str_pad(($p % 28) + 1, 2, '0', STR_PAD_LEFT);
            $telPad = '95' . str_pad(2000000 + $p * 7, 7, '0', STR_PAD_LEFT);
            $dist   = $distritos[$p % 10];
            $call   = $calles[($p + 3) % 10];
            $numP   = 200 + ($p % 800);
            $dniP   = ($isMale ? '4' : '6') . str_pad(5000000 + $p, 7, '0', STR_PAD_LEFT);

            $r = ($p * 13 + 7) % 100 + 1;
            $gradoInstr = match (true) {
                $r <= 3  => 'sin_instruccion',
                $r <= 23 => 'primaria',
                $r <= 68 => 'secundaria',
                $r <= 88 => 'tecnico',
                $r <= 98 => 'universitario',
                default  => 'posgrado',
            };

            $pProfRows[] = [
                'parent_id'         => 0,
                'dni'               => $dniP,
                'telefono'          => $telPad,
                'direccion'         => "{$call} {$numP}, {$dist}",
                'ocupacion'         => $ocupaciones[$p % 10],
                'grado_instruccion' => $gradoInstr,
                'created_at'        => $now,
                'updated_at'        => $now,
            ];
        }

        foreach (array_chunk($parentRows, 200) as $chunk) {
            DB::table('users')->insert($chunk);
        }
        $parentIds = User::where('role', 'parent')->orderBy('id')->pluck('id')->toArray();
        foreach ($pProfRows as $i => &$row) {
            $row['parent_id'] = $parentIds[$i];
        }
        unset($row);
        foreach (array_chunk($pProfRows, 200) as $chunk) {
            DB::table('parent_profiles')->insert($chunk);
        }
    }
}
