<?php

namespace Database\Seeders;

use App\Models\Section;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ScheduleSeeder extends Seeder
{
    public function run(): void
    {
        // Franjas horarias según turno
        $slotsMañana = [
            ['07:30', '08:10'],
            ['08:10', '08:50'],
            ['08:50', '09:30'],
            ['09:30', '10:10'],
            // Receso 10:10-10:30
            ['10:30', '11:10'],
            ['11:10', '11:50'],
            ['11:50', '12:30'],
        ];
        $slotsTarde = [
            ['13:00', '13:40'],
            ['13:40', '14:20'],
            ['14:20', '15:00'],
            ['15:00', '15:40'],
            // Receso 15:40-16:00
            ['16:00', '16:40'],
            ['16:40', '17:20'],
            ['17:20', '18:00'],
        ];

        // Distribución semanal (35 horas = 5 días × 7 períodos)
        $weekTemplate = [
            'lunes'     => ['Matemática','Matemática','Comunicación','Comunicación',
                            'Ciencia y Tecnología','Ciencia y Tecnología','Inglés'],
            'martes'    => ['Matemática','Matemática','Comunicación','Comunicación',
                            'Ciencias Sociales','Ciencias Sociales','Inglés'],
            'miercoles' => ['Matemática','Comunicación','Inglés','Ciencia y Tecnología',
                            'Ciencia y Tecnología','Ciencias Sociales','Ciencias Sociales'],
            'jueves'    => ['Desarrollo Personal, Ciudadanía y Cívica',
                            'Desarrollo Personal, Ciudadanía y Cívica',
                            'Educación Física','Educación Física',
                            'Arte y Cultura','Arte y Cultura','Educación para el Trabajo'],
            'viernes'   => ['Educación para el Trabajo','Educación Religiosa','Educación Religiosa',
                            'Educación Física','Lengua Originaria','Lengua Originaria','Lengua Originaria'],
        ];

        // Solo secciones del año activo 2026
        $sections = Section::where('year', 2026)->with('courses')->get();
        $rows     = [];
        $now      = now();

        foreach ($sections as $section) {
            $isMañana  = $section->turno === 'mañana';
            $slotTimes = $isMañana ? $slotsMañana : $slotsTarde;
            $classroom = 'Aula ' . $section->name;
            $courseMap = $section->courses->keyBy('name');

            foreach ($weekTemplate as $day => $slots) {
                foreach ($slots as $slotIdx => $courseName) {
                    $course = $courseMap->get($courseName);
                    if (!$course) continue;

                    $rows[] = [
                        'course_id'   => $course->id,
                        'day_of_week' => $day,
                        'start_time'  => $slotTimes[$slotIdx][0],
                        'end_time'    => $slotTimes[$slotIdx][1],
                        'classroom'   => $classroom,
                        'created_at'  => $now,
                        'updated_at'  => $now,
                    ];
                }
            }
        }

        foreach (array_chunk($rows, 500) as $chunk) {
            DB::table('schedule_slots')->insert($chunk);
        }
        // 35 slots × 50 secciones 2026 = 1 750 slots
    }
}
