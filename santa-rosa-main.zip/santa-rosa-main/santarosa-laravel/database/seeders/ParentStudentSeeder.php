<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ParentStudentSeeder extends Seeder
{
    public function run(): void
    {
        $parents  = User::where('role', 'parent')->orderBy('id')->get();
        $students = User::where('role', 'student')->orderBy('id')->pluck('id')->toArray();
        // 750 padres, 1500 alumnos
        // Emparejamiento: padre i → alumno i (grados 1-3) + alumno i+750 (grados 4-5)
        // Así los hermanos están en grados diferentes (más realista)

        $linkRows    = [];
        $profileUpdates = [];
        $now         = now();

        foreach ($parents as $i => $parent) {
            // Determinar parentesco según género del padre
            // Padres pares (índice 0,2,4...) = masculino → 'padre'
            // Padres impares (índice 1,3,5...) = femenino → 'madre'
            $parentesco = ($i % 2 === 0) ? 'padre' : 'madre';

            $child1Id = $students[$i]          ?? null;
            $child2Id = $students[$i + 750]    ?? null;

            if ($child1Id) {
                $linkRows[] = [
                    'parent_id'  => $parent->id,
                    'student_id' => $child1Id,
                    'parentesco' => $parentesco,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];
                $profileUpdates[] = [
                    'student_id'          => $child1Id,
                    'nombre_apoderado'    => $parent->name,
                    'dni_apoderado'       => DB::table('parent_profiles')
                                              ->where('parent_id', $parent->id)
                                              ->value('dni'),
                    'telefono_emergencia' => DB::table('parent_profiles')
                                              ->where('parent_id', $parent->id)
                                              ->value('telefono'),
                ];
            }

            if ($child2Id) {
                $linkRows[] = [
                    'parent_id'  => $parent->id,
                    'student_id' => $child2Id,
                    'parentesco' => $parentesco,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];
                $profileUpdates[] = [
                    'student_id'          => $child2Id,
                    'nombre_apoderado'    => $parent->name,
                    'dni_apoderado'       => DB::table('parent_profiles')
                                              ->where('parent_id', $parent->id)
                                              ->value('dni'),
                    'telefono_emergencia' => DB::table('parent_profiles')
                                              ->where('parent_id', $parent->id)
                                              ->value('telefono'),
                ];
            }
        }

        DB::table('parent_students')->insertOrIgnore($linkRows);

        // Actualizar nombre_apoderado y teléfono de emergencia en student_profiles
        foreach ($profileUpdates as $upd) {
            DB::table('student_profiles')
              ->where('student_id', $upd['student_id'])
              ->update([
                  'nombre_apoderado'    => $upd['nombre_apoderado'],
                  'dni_apoderado'       => $upd['dni_apoderado'],
                  'telefono_emergencia' => $upd['telefono_emergencia'],
              ]);
        }
        // 750 padres × 2 hijos = 1 500 vínculos, hermanos en grados distintos
    }
}
