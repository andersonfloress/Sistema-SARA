<?php

namespace Database\Seeders;

use App\Models\Section;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EnrollmentSeeder extends Seeder
{
    public function run(): void
    {
        $now      = now();
        $students = User::where('role', 'student')->orderBy('id')->pluck('id')->toArray();
        // 1500 alumnos en orden: grado 1 primero (secciones 1-10), luego grado 2, etc.

        // ── Matrículas 2026 — 1 500 alumnos en 50 secciones ──────────────
        $sections2026 = Section::where('year', 2026)->orderBy('grade')->orderBy('name')->pluck('id')->toArray();
        // 50 secciones en orden: 1°A..1°J, 2°A..2°J, ..., 5°A..5°J

        $rows = [];
        foreach ($sections2026 as $i => $sectionId) {
            $chunk = array_slice($students, $i * 30, 30);
            foreach ($chunk as $studentId) {
                $rows[] = [
                    'student_id'  => $studentId,
                    'section_id'  => $sectionId,
                    'year'        => 2026,
                    'result'      => null,
                    'enrolled_at' => '2026-03-03',
                    'created_at'  => $now,
                    'updated_at'  => $now,
                ];
            }
        }
        DB::table('enrollments')->insert($rows);

        // ── Matrículas históricas 2025 — solo alumnos de 5° en 2026 ──────
        // En 2025 cursaban 4°; ahora están en 5°. Los promovemos con result='approved'.
        // Secciones 2025 (4°A..4°J) = IDs 51-60 (en orden A-J)
        $sections2025 = Section::where('year', 2025)->orderBy('name')->pluck('id')->toArray();

        // Alumnos de 5° en 2026 = índices 1200-1499 (secciones 41-50 del array 2026)
        $quintoStudents = array_slice($students, 1200, 300);

        $histRows = [];
        foreach ($sections2025 as $j => $histSectionId) {
            $chunk = array_slice($quintoStudents, $j * 30, 30);
            foreach ($chunk as $studentId) {
                $histRows[] = [
                    'student_id'  => $studentId,
                    'section_id'  => $histSectionId,
                    'year'        => 2025,
                    'result'      => 'approved',
                    'enrolled_at' => '2025-03-03',
                    'created_at'  => $now,
                    'updated_at'  => $now,
                ];
            }
        }
        DB::table('enrollments')->insert($histRows);
        // Total: 1500 + 300 = 1800 matrículas
    }
}
